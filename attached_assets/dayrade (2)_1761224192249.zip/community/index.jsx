import React from "react";
import { Navbar6 } from "./components/Navbar6";
import { Header83 } from "./components/Header83";
import { Layout16 } from "./components/Layout16";
import { Layout423 } from "./components/Layout423";
import { Layout1 } from "./components/Layout1";
import { Layout192 } from "./components/Layout192";
import { Footer3 } from "./components/Footer3";

export default function Page() {
  return (
    <div>
      <Navbar6 />
      <Header83 />
      <Layout16 />
      <Layout423 />
      <Layout1 />
      <Layout192 />
      <Footer3 />
    </div>
  );
}
