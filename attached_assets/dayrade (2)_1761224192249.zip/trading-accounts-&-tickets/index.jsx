import React from "react";
import { Navbar6 } from "./components/Navbar6";
import { Header83 } from "./components/Header83";
import { Layout16 } from "./components/Layout16";
import { Layout13 } from "./components/Layout13";
import { Layout19 } from "./components/Layout19";
import { Cta31 } from "./components/Cta31";
import { Footer3 } from "./components/Footer3";

export default function Page() {
  return (
    <div>
      <Navbar6 />
      <Header83 />
      <Layout16 />
      <Layout13 />
      <Layout19 />
      <Cta31 />
      <Footer3 />
    </div>
  );
}
