import React from "react";
import { Navbar6 } from "./components/Navbar6";
import { Header83 } from "./components/Header83";
import { Layout22 } from "./components/Layout22";
import { Layout10 } from "./components/Layout10";
import { Layout213 } from "./components/Layout213";
import { Layout192 } from "./components/Layout192";
import { Layout1 } from "./components/Layout1";
import { Layout13 } from "./components/Layout13";
import { Layout504 } from "./components/Layout504";
import { Contact15 } from "./components/Contact15";
import { Footer3 } from "./components/Footer3";

export default function Page() {
  return (
    <div>
      <Navbar6 />
      <Header83 />
      <Layout22 />
      <Layout10 />
      <Layout213 />
      <Layout192 />
      <Layout1 />
      <Layout13 />
      <Layout504 />
      <Contact15 />
      <Footer3 />
    </div>
  );
}
