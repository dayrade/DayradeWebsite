import React from "react";
import { Navbar6 } from "./components/Navbar6";
import { Header83 } from "./components/Header83";
import { Layout369 } from "./components/Layout369";
import { Layout239 } from "./components/Layout239";
import { Layout514 } from "./components/Layout514";
import { Layout514_1 } from "./components/Layout514_1";
import { Cta31 } from "./components/Cta31";
import { Header83_1 } from "./components/Header83_1";
import { Layout145 } from "./components/Layout145";
import { Layout513 } from "./components/Layout513";
import { Footer3 } from "./components/Footer3";

export default function Page() {
  return (
    <div>
      <Navbar6 />
      <Header83 />
      <Layout369 />
      <Layout239 />
      <Layout514 />
      <Layout514_1 />
      <Cta31 />
      <Header83_1 />
      <Layout145 />
      <Layout513 />
      <Footer3 />
    </div>
  );
}
