import React from "react";
import { Navbar6 } from "./components/Navbar6";
import { Header64 } from "./components/Header64";
import { Layout22 } from "./components/Layout22";
import { Layout29 } from "./components/Layout29";
import { Testimonial17 } from "./components/Testimonial17";
import { Layout386 } from "./components/Layout386";
import { Layout251 } from "./components/Layout251";
import { Cta31 } from "./components/Cta31";
import { Contact15 } from "./components/Contact15";
import { Footer3 } from "./components/Footer3";

export default function Page() {
  return (
    <div>
      <Navbar6 />
      <Header64 />
      <Layout22 />
      <Layout29 />
      <Testimonial17 />
      <Layout386 />
      <Layout251 />
      <Cta31 />
      <Contact15 />
      <Footer3 />
    </div>
  );
}
