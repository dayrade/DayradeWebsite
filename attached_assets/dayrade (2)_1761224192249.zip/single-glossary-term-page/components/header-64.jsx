"use client";

import React from "react";

export function Header64() {
  return (
    <section id="relume" className="px-[5%] py-16 md:py-24 lg:py-28">
      <div className="container max-w-lg text-center">
        <h1 className="mb-5 text-6xl font-bold md:mb-6 md:text-9xl lg:text-10xl">
          Candlestick pattern
        </h1>
        <p className="md:text-md">
          A visual representation of price movement in financial markets that
          reveals trader sentiment and potential market direction.
        </p>
      </div>
    </section>
  );
}
