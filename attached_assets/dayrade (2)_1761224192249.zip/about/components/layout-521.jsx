"use client";

import { Button } from "@relume_io/relume-ui";
import React from "react";
import { RxChevronRight } from "react-icons/rx";

export function Layout521() {
  return (
    <section id="relume" className="px-[5%] py-16 md:py-24 lg:py-28">
      <div className="container">
        <div className="mb-12 md:mb-18 lg:mb-20">
          <div className="mx-auto max-w-lg text-center">
            <p className="mb-3 font-semibold md:mb-4">Values</p>
            <h2 className="mb-5 text-5xl font-bold md:mb-6 md:text-7xl lg:text-8xl">
              Our core principles
            </h2>
            <p className="md:text-md">
              Guiding our mission with unwavering commitment
            </p>
          </div>
        </div>
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 md:gap-8 lg:grid-cols-4">
          <div className="relative p-6 text-text-alternative">
            <div className="absolute inset-0 -z-10">
              <div className="absolute inset-0 bg-black/50" />
              <img
                src="https://d22po4pjz3o32e.cloudfront.net/placeholder-image.svg"
                className="size-full object-cover"
                alt="Relume placeholder image"
              />
            </div>
            <div className="mb-3 md:mb-4">
              <img
                src="https://d22po4pjz3o32e.cloudfront.net/relume-icon-white.svg"
                className="size-12"
                alt="Relume logo"
              />
            </div>
            <h3 className="mb-2 text-xl font-bold md:text-2xl">Integrity</h3>
            <p>Transparent operations that ensure fair play for all</p>
            <div className="mt-5 flex items-center md:mt-6">
              <Button
                variant="link-alt"
                size="link"
                iconRight={<RxChevronRight />}
              >
                Explore
              </Button>
            </div>
          </div>
          <div className="relative p-6 text-text-alternative">
            <div className="absolute inset-0 -z-10">
              <div className="absolute inset-0 bg-black/50" />
              <img
                src="https://d22po4pjz3o32e.cloudfront.net/placeholder-image.svg"
                className="size-full object-cover"
                alt="Relume placeholder image"
              />
            </div>
            <div className="mb-3 md:mb-4">
              <img
                src="https://d22po4pjz3o32e.cloudfront.net/relume-icon-white.svg"
                className="size-12"
                alt="Relume logo"
              />
            </div>
            <h3 className="mb-2 text-xl font-bold md:text-2xl">Education</h3>
            <p>Empowering traders with knowledge and skills</p>
            <div className="mt-5 flex items-center md:mt-6">
              <Button
                variant="link-alt"
                size="link"
                iconRight={<RxChevronRight />}
              >
                Learn
              </Button>
            </div>
          </div>
          <div className="relative p-6 text-text-alternative">
            <div className="absolute inset-0 -z-10">
              <div className="absolute inset-0 bg-black/50" />
              <img
                src="https://d22po4pjz3o32e.cloudfront.net/placeholder-image.svg"
                className="size-full object-cover"
                alt="Relume placeholder image"
              />
            </div>
            <div className="mb-3 md:mb-4">
              <img
                src="https://d22po4pjz3o32e.cloudfront.net/relume-icon-white.svg"
                className="size-12"
                alt="Relume logo"
              />
            </div>
            <h3 className="mb-2 text-xl font-bold md:text-2xl">Community</h3>
            <p>Building a supportive network of passionate traders</p>
            <div className="mt-5 flex items-center md:mt-6">
              <Button
                variant="link-alt"
                size="link"
                iconRight={<RxChevronRight />}
              >
                Connect
              </Button>
            </div>
          </div>
          <div className="relative p-6 text-text-alternative">
            <div className="absolute inset-0 -z-10">
              <div className="absolute inset-0 bg-black/50" />
              <img
                src="https://d22po4pjz3o32e.cloudfront.net/placeholder-image.svg"
                className="size-full object-cover"
                alt="Relume placeholder image"
              />
            </div>
            <div className="mb-3 md:mb-4">
              <img
                src="https://d22po4pjz3o32e.cloudfront.net/relume-icon-white.svg"
                className="size-12"
                alt="Relume logo"
              />
            </div>
            <h3 className="mb-2 text-xl font-bold md:text-2xl">Innovation</h3>
            <p>Continuously improving our platform and features</p>
            <div className="mt-5 flex items-center md:mt-6">
              <Button
                variant="link-alt"
                size="link"
                iconRight={<RxChevronRight />}
              >
                Discover
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
