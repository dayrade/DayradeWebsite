import React from "react";
import { Navbar6 } from "./components/Navbar6";
import { Header83 } from "./components/Header83";
import { Layout22 } from "./components/Layout22";
import { Layout13 } from "./components/Layout13";
import { Layout521 } from "./components/Layout521";
import { Team22 } from "./components/Team22";
import { Testimonial17 } from "./components/Testimonial17";
import { Layout141 } from "./components/Layout141";
import { Footer3 } from "./components/Footer3";

export default function Page() {
  return (
    <div>
      <Navbar6 />
      <Header83 />
      <Layout22 />
      <Layout13 />
      <Layout521 />
      <Team22 />
      <Testimonial17 />
      <Layout141 />
      <Footer3 />
    </div>
  );
}
