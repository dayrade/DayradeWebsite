import React from "react";
import { Navbar6 } from "./components/Navbar6";
import { Header83 } from "./components/Header83";
import { Layout145 } from "./components/Layout145";
import { Layout513 } from "./components/Layout513";
import { Layout520 } from "./components/Layout520";
import { Footer3 } from "./components/Footer3";

export default function Page() {
  return (
    <div>
      <Navbar6 />
      <Header83 />
      <Layout145 />
      <Layout513 />
      <Layout520 />
      <Footer3 />
    </div>
  );
}
