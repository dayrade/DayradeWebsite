import React from "react";
import { Navbar6 } from "./components/Navbar6";
import { BlogPostHeader1 } from "./components/BlogPostHeader1";
import { Layout149 } from "./components/Layout149";
import { Content30 } from "./components/Content30";
import { Layout394 } from "./components/Layout394";
import { Layout525 } from "./components/Layout525";
import { Cta31 } from "./components/Cta31";
import { Testimonial17 } from "./components/Testimonial17";
import { Contact15 } from "./components/Contact15";
import { Cta32 } from "./components/Cta32";
import { Footer3 } from "./components/Footer3";

export default function Page() {
  return (
    <div>
      <Navbar6 />
      <BlogPostHeader1 />
      <Layout149 />
      <Content30 />
      <Layout394 />
      <Layout525 />
      <Cta31 />
      <Testimonial17 />
      <Contact15 />
      <Cta32 />
      <Footer3 />
    </div>
  );
}
