"use client";

import { Button } from "@relume_io/relume-ui";
import React from "react";
import { RxChevronRight } from "react-icons/rx";

export function Layout525() {
  return (
    <section id="relume" className="px-[5%] py-16 md:py-24 lg:py-28">
      <div className="container">
        <div className="mb-12 md:mb-18 lg:mb-20">
          <div className="mx-auto max-w-lg text-center">
            <p className="mb-3 font-semibold md:mb-4">Benefits</p>
            <h2 className="mb-5 text-5xl font-bold md:mb-6 md:text-7xl lg:text-8xl">
              Transform your trading approach
            </h2>
            <p className="md:text-md">
              Unlock potential through strategic learning and disciplined
              execution
            </p>
          </div>
        </div>
        <div className="grid grid-cols-1 gap-6 md:gap-8 lg:grid-cols-2">
          <div className="relative flex flex-col justify-center p-6 text-text-alternative md:p-8 lg:p-12">
            <div className="absolute inset-0 -z-10">
              <div className="absolute inset-0 bg-black/50" />
              <img
                src="https://d22po4pjz3o32e.cloudfront.net/placeholder-image.svg"
                className="size-full object-cover"
                alt="Relume placeholder image"
              />
            </div>
            <div>
              <div>
                <p className="mb-2 inline-block text-sm font-semibold">
                  Growth
                </p>
                <h2 className="mb-5 text-4xl font-bold leading-[1.2] md:mb-6 md:text-5xl lg:text-6xl">
                  Improved risk management
                </h2>
                <p>
                  Develop a systematic approach to minimize potential losses and
                  maximize gains
                </p>
              </div>
              <div className="mt-6 flex flex-wrap items-center gap-4 md:mt-8">
                <Button title="Practice" variant="secondary-alt">
                  Practice
                </Button>
                <Button
                  title="Explore"
                  variant="link-alt"
                  size="link"
                  iconRight={<RxChevronRight />}
                >
                  Explore
                </Button>
              </div>
            </div>
          </div>
          <div className="grid grid-cols-1 gap-8">
            <div className="grid grid-cols-1 gap-8 sm:grid-cols-2">
              <div className="relative flex flex-col p-6 text-text-alternative md:p-8 lg:p-6">
                <div className="absolute inset-0 -z-10">
                  <div className="absolute inset-0 bg-black/50" />
                  <img
                    src="https://d22po4pjz3o32e.cloudfront.net/placeholder-image.svg"
                    className="size-full object-cover"
                    alt="Relume placeholder image"
                  />
                </div>
                <div className="flex flex-1 flex-col justify-between">
                  <div>
                    <div className="mb-3 md:mb-4">
                      <img
                        src="https://d22po4pjz3o32e.cloudfront.net/relume-icon-white.svg"
                        className="size-12"
                        alt="Relume logo"
                      />
                    </div>
                    <h3 className="mb-2 text-xl font-bold md:text-2xl">
                      Enhanced decision-making skills
                    </h3>
                    <p>
                      Build confidence through structured learning and practical
                      application
                    </p>
                  </div>
                  <div className="mt-5 flex items-center md:mt-6">
                    <Button
                      title="Learn"
                      variant="link-alt"
                      size="link"
                      iconRight={<RxChevronRight />}
                    >
                      Learn
                    </Button>
                  </div>
                </div>
              </div>
              <div className="relative flex flex-col p-6 text-text-alternative md:p-8 lg:p-6">
                <div className="absolute inset-0 -z-10">
                  <div className="absolute inset-0 bg-black/50" />
                  <img
                    src="https://d22po4pjz3o32e.cloudfront.net/placeholder-image.svg"
                    className="size-full object-cover"
                    alt="Relume placeholder image"
                  />
                </div>
                <div className="flex flex-1 flex-col justify-between">
                  <div>
                    <div className="mb-3 md:mb-4">
                      <img
                        src="https://d22po4pjz3o32e.cloudfront.net/relume-icon-white.svg"
                        className="size-12"
                        alt="Relume logo"
                      />
                    </div>
                    <h3 className="mb-2 text-xl font-bold md:text-2xl">
                      Long-term financial strategy
                    </h3>
                    <p>
                      Create sustainable trading practices for consistent
                      performance
                    </p>
                  </div>
                  <div className="mt-5 flex items-center md:mt-6">
                    <Button
                      title="Discover"
                      variant="link-alt"
                      size="link"
                      iconRight={<RxChevronRight />}
                    >
                      Discover
                    </Button>
                  </div>
                </div>
              </div>
            </div>
            <div className="relative flex flex-col p-6 text-text-alternative md:p-8 lg:p-12">
              <div className="absolute inset-0 -z-10">
                <div className="absolute inset-0 bg-black/50" />
                <img
                  src="https://d22po4pjz3o32e.cloudfront.net/placeholder-image.svg"
                  className="size-full object-cover"
                  alt="Relume placeholder image"
                />
              </div>
              <div className="flex flex-1 flex-col justify-between">
                <div>
                  <div className="mb-3 md:mb-4">
                    <img
                      src="https://d22po4pjz3o32e.cloudfront.net/relume-icon-white.svg"
                      className="size-12"
                      alt="Relume logo"
                    />
                  </div>
                  <h3 className="mb-5 text-4xl font-bold leading-[1.2] md:mb-6 md:text-5xl lg:text-6xl">
                    Continuous learning path
                  </h3>
                  <p>
                    Access ongoing resources, tournaments, and community support
                    to accelerate your trading journey
                  </p>
                </div>
                <div className="mt-6 flex flex-wrap items-center gap-4 md:mt-8">
                  <Button title="Start now" variant="secondary-alt">
                    Start now
                  </Button>
                  <Button
                    title="Learn more"
                    variant="link-alt"
                    size="link"
                    iconRight={<RxChevronRight />}
                  >
                    Learn more
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
