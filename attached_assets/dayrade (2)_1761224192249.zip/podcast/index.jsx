import React from "react";
import { Navbar6 } from "./components/Navbar6";
import { Header83 } from "./components/Header83";
import { Layout514 } from "./components/Layout514";
import { Layout514_1 } from "./components/Layout514_1";
import { Layout163 } from "./components/Layout163";
import { Footer3 } from "./components/Footer3";

export default function Page() {
  return (
    <div>
      <Navbar6 />
      <Header83 />
      <Layout514 />
      <Layout514_1 />
      <Layout163 />
      <Footer3 />
    </div>
  );
}
