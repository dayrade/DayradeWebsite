import React from "react";
import { Navbar6 } from "./components/Navbar6";
import { Header83 } from "./components/Header83";
import { Layout13 } from "./components/Layout13";
import { Layout521 } from "./components/Layout521";
import { Layout16 } from "./components/Layout16";
import { Footer3 } from "./components/Footer3";

export default function Page() {
  return (
    <div>
      <Navbar6 />
      <Header83 />
      <Layout13 />
      <Layout521 />
      <Layout16 />
      <Footer3 />
    </div>
  );
}
