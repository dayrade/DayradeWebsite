import React from "react";
import { Navbar6 } from "./components/Navbar6";
import { Header83 } from "./components/Header83";
import { Layout359 } from "./components/Layout359";
import { Layout239 } from "./components/Layout239";
import { Cta31 } from "./components/Cta31";
import { Footer3 } from "./components/Footer3";

export default function Page() {
  return (
    <div>
      <Navbar6 />
      <Header83 />
      <Layout359 />
      <Layout239 />
      <Cta31 />
      <Footer3 />
    </div>
  );
}
