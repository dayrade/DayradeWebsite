import React from "react";
import { Navbar6 } from "./components/Navbar6";
import { Header83 } from "./components/Header83";
import { Layout141 } from "./components/Layout141";
import { Layout356 } from "./components/Layout356";
import { Layout520 } from "./components/Layout520";
import { Layout210 } from "./components/Layout210";
import { Footer3 } from "./components/Footer3";

export default function Page() {
  return (
    <div>
      <Navbar6 />
      <Header83 />
      <Layout141 />
      <Layout356 />
      <Layout520 />
      <Layout210 />
      <Footer3 />
    </div>
  );
}
