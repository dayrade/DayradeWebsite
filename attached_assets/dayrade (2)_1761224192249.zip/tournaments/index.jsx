import React from "react";
import { Navbar6 } from "./components/Navbar6";
import { Header83 } from "./components/Header83";
import { Layout357 } from "./components/Layout357";
import { Layout419 } from "./components/Layout419";
import { Layout514 } from "./components/Layout514";
import { Cta31 } from "./components/Cta31";
import { Footer3 } from "./components/Footer3";

export default function Page() {
  return (
    <div>
      <Navbar6 />
      <Header83 />
      <Layout357 />
      <Layout419 />
      <Layout514 />
      <Cta31 />
      <Footer3 />
    </div>
  );
}
