import React from "react";
import { Navbar6 } from "./components/Navbar6";
import { Header83 } from "./components/Header83";
import { Layout504 } from "./components/Layout504";
import { Layout207 } from "./components/Layout207";
import { Cta31 } from "./components/Cta31";
import { Footer3 } from "./components/Footer3";

export default function Page() {
  return (
    <div>
      <Navbar6 />
      <Header83 />
      <Layout504 />
      <Layout207 />
      <Cta31 />
      <Footer3 />
    </div>
  );
}
