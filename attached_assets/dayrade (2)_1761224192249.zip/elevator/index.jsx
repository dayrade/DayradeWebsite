import React from "react";
import { Navbar6 } from "./components/Navbar6";
import { Header83 } from "./components/Header83";
import { Layout491 } from "./components/Layout491";
import { Layout491_1 } from "./components/Layout491_1";
import { Layout503 } from "./components/Layout503";
import { Layout410 } from "./components/Layout410";
import { Layout19 } from "./components/Layout19";
import { Footer3 } from "./components/Footer3";

export default function Page() {
  return (
    <div>
      <Navbar6 />
      <Header83 />
      <Layout491 />
      <Layout491_1 />
      <Layout503 />
      <Layout410 />
      <Layout19 />
      <Footer3 />
    </div>
  );
}
