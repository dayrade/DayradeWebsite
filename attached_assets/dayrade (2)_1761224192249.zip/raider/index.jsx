import React from "react";
import { Navbar6 } from "./components/Navbar6";
import { Header83 } from "./components/Header83";
import { Layout141 } from "./components/Layout141";
import { Layout521 } from "./components/Layout521";
import { Layout149 } from "./components/Layout149";
import { Cta31 } from "./components/Cta31";
import { Stats40 } from "./components/Stats40";
import { Testimonial17 } from "./components/Testimonial17";
import { Contact15 } from "./components/Contact15";
import { Footer3 } from "./components/Footer3";

export default function Page() {
  return (
    <div>
      <Navbar6 />
      <Header83 />
      <Layout141 />
      <Layout521 />
      <Layout149 />
      <Cta31 />
      <Stats40 />
      <Testimonial17 />
      <Contact15 />
      <Footer3 />
    </div>
  );
}
