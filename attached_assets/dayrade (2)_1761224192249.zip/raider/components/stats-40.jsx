"use client";

import React from "react";

export function Stats40() {
  return (
    <section id="relume" className="px-[5%] py-16 md:py-24 lg:py-28">
      <div className="container">
        <div className="mb-12 max-w-lg md:mb-18 lg:mb-20">
          <h3 className="text-4xl font-bold leading-[1.2] md:text-5xl lg:text-6xl">
            Raider Division performance metrics that define excellence
          </h3>
        </div>
        <div className="grid grid-cols-1 gap-8 lg:grid-cols-3">
          <div className="border border-border-primary p-8">
            <h3 className="mb-8 text-md font-bold leading-[1.4] md:mb-10 md:text-xl lg:mb-12">
              Prize pools
            </h3>
            <p className="text-right text-10xl font-bold leading-[1.3] md:text-[4rem] lg:text-[5rem]">
              $10K
            </p>
            <div className="my-4 h-px w-full bg-border-primary" />
            <p className="text-right">Average tournament prize money</p>
          </div>
          <div className="border border-border-primary p-8">
            <h3 className="mb-8 text-md font-bold leading-[1.4] md:mb-10 md:text-xl lg:mb-12">
              Success rate
            </h3>
            <p className="text-right text-10xl font-bold leading-[1.3] md:text-[4rem] lg:text-[5rem]">
              85%
            </p>
            <div className="my-4 h-px w-full bg-border-primary" />
            <p className="text-right">
              Top traders achieving consistent results
            </p>
          </div>
          <div className="border border-border-primary p-8">
            <h3 className="mb-8 text-md font-bold leading-[1.4] md:mb-10 md:text-xl lg:mb-12">
              Community growth
            </h3>
            <p className="text-right text-10xl font-bold leading-[1.3] md:text-[4rem] lg:text-[5rem]">
              500+
            </p>
            <div className="my-4 h-px w-full bg-border-primary" />
            <p className="text-right">Elite traders competing monthly</p>
          </div>
        </div>
      </div>
    </section>
  );
}
