import React from "react";
import { Navbar6 } from "./components/Navbar6";
import { Header14 } from "./components/Header14";
import { Footer3 } from "./components/Footer3";

export default function Page() {
  return (
    <div>
      <Navbar6 />
      <Header14 />
      <Footer3 />
    </div>
  );
}
