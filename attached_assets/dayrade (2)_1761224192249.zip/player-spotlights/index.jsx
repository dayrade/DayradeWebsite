import React from "react";
import { Navbar6 } from "./components/Navbar6";
import { Header83 } from "./components/Header83";
import { Layout4 } from "./components/Layout4";
import { Gallery5 } from "./components/Gallery5";
import { Layout145 } from "./components/Layout145";
import { Layout371 } from "./components/Layout371";
import { Cta31 } from "./components/Cta31";
import { Footer3 } from "./components/Footer3";

export default function Page() {
  return (
    <div>
      <Navbar6 />
      <Header83 />
      <Layout4 />
      <Gallery5 />
      <Layout145 />
      <Layout371 />
      <Cta31 />
      <Footer3 />
    </div>
  );
}
