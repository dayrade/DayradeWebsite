import React from "react";
import { Navbar6 } from "./components/Navbar6";
import { Header83 } from "./components/Header83";
import { Layout141 } from "./components/Layout141";
import { Layout149 } from "./components/Layout149";
import { Header80 } from "./components/Header80";
import { Layout145 } from "./components/Layout145";
import { Layout155 } from "./components/Layout155";
import { Layout141_1 } from "./components/Layout141_1";
import { Layout141_2 } from "./components/Layout141_2";
import { Layout145_1 } from "./components/Layout145_1";
import { Footer3 } from "./components/Footer3";

export default function Page() {
  return (
    <div>
      <Navbar6 />
      <Header83 />
      <Layout141 />
      <Layout149 />
      <Header80 />
      <Layout145 />
      <Layout155 />
      <Layout141_1 />
      <Layout141_2 />
      <Layout145_1 />
      <Footer3 />
    </div>
  );
}
