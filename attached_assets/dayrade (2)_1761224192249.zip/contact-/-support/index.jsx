import React from "react";
import { Navbar6 } from "./components/Navbar6";
import { Header83 } from "./components/Header83";
import { Layout163 } from "./components/Layout163";
import { Layout145 } from "./components/Layout145";
import { Layout163_1 } from "./components/Layout163_1";
import { Contact15 } from "./components/Contact15";
import { Contact7 } from "./components/Contact7";
import { Faq4 } from "./components/Faq4";
import { Footer3 } from "./components/Footer3";

export default function Page() {
  return (
    <div>
      <Navbar6 />
      <Header83 />
      <Layout163 />
      <Layout145 />
      <Layout163_1 />
      <Contact15 />
      <Contact7 />
      <Faq4 />
      <Footer3 />
    </div>
  );
}
