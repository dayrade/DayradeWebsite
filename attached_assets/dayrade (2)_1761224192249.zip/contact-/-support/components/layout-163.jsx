"use client";

import { Button } from "@relume_io/relume-ui";
import React from "react";
import { RxChevronRight } from "react-icons/rx";

export function Layout163() {
  return (
    <section id="relume" className="px-[5%] py-16 md:py-24 lg:py-28">
      <div className="container">
        <div className="flex flex-col items-center">
          <div>
            <img
              src="https://d22po4pjz3o32e.cloudfront.net/placeholder-image-landscape.svg"
              className="size-full object-cover"
              alt="Relume placeholder image"
            />
          </div>
          <div className="rb-12 mt-12 md:mt-18 lg:mt-20">
            <div className="mx-auto text-center">
              <div className="flex max-w-lg flex-col items-center justify-start">
                <p className="mb-3 font-semibold md:mb-4">Support</p>
                <h2 className="rb-5 mb-5 text-5xl font-bold md:mb-6 md:text-7xl lg:text-8xl">
                  Instant answers
                </h2>
                <p className="mb-5 md:mb-6 md:text-md">
                  Navigate our comprehensive help center for quick solutions to
                  common trading and platform questions.
                </p>
                <div className="flex flex-wrap items-center justify-center gap-x-8 gap-y-6 py-2">
                  <img
                    src="https://d22po4pjz3o32e.cloudfront.net/webflow-logo.svg"
                    alt="Webflow logo 1"
                    className="max-h-14"
                  />
                  <img
                    src="https://d22po4pjz3o32e.cloudfront.net/relume-logo.svg"
                    alt="Relume logo 1"
                    className="max-h-14"
                  />
                  <img
                    src="https://d22po4pjz3o32e.cloudfront.net/webflow-logo.svg"
                    alt="Webflow logo 2"
                    className="max-h-14"
                  />
                  <img
                    src="https://d22po4pjz3o32e.cloudfront.net/relume-logo.svg"
                    alt="Relume logo 2"
                    className="max-h-14"
                  />
                </div>
                <div className="mt-6 flex flex-wrap items-center justify-center gap-4 md:mt-8">
                  <Button title="Search Help Center" variant="secondary">
                    Search Help Center
                  </Button>
                  <Button
                    title="Learn More"
                    variant="link"
                    size="link"
                    iconRight={<RxChevronRight />}
                  >
                    Learn More
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
