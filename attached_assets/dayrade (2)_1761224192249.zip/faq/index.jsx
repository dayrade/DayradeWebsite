import React from "react";
import { Navbar6 } from "./components/Navbar6";
import { Header83 } from "./components/Header83";
import { Faq4 } from "./components/Faq4";
import { Faq4_1 } from "./components/Faq4_1";
import { Faq4_2 } from "./components/Faq4_2";
import { Faq4_3 } from "./components/Faq4_3";
import { Cta31 } from "./components/Cta31";
import { Footer3 } from "./components/Footer3";

export default function Page() {
  return (
    <div>
      <Navbar6 />
      <Header83 />
      <Faq4 />
      <Faq4_1 />
      <Faq4_2 />
      <Faq4_3 />
      <Cta31 />
      <Footer3 />
    </div>
  );
}
