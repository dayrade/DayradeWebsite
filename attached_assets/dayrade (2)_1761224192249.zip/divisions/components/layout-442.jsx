"use client";

import { Button } from "@relume_io/relume-ui";
import React from "react";
import { RxChevronRight } from "react-icons/rx";

export function Layout442() {
  return (
    <section id="relume" className="relative px-[5%] py-16 md:py-24 lg:py-28">
      <div className="container">
        <div className="grid grid-cols-1 gap-x-12 gap-y-5 md:grid-cols-2 lg:gap-x-20">
          <div>
            <p className="mb-3 font-semibold text-text-alternative md:mb-4">
              Rewards
            </p>
            <h2 className="text-5xl font-bold text-text-alternative md:text-7xl lg:text-8xl">
              Win more than just money
            </h2>
          </div>
          <div className="mx-[7.5%] md:mt-48">
            <p className="text-text-alternative md:text-md">
              Top performers earn cash prizes, recognition, and a permanent mark
              on the community leaderboard. Your trading journey becomes a
              visible achievement.
            </p>
            <div className="mt-6 flex flex-wrap gap-4 md:mt-8">
              <Button title="View leaderboard" variant="secondary-alt">
                View leaderboard
              </Button>
              <Button
                title="Explore achievements"
                variant="link-alt"
                size="link"
                iconRight={<RxChevronRight />}
              >
                Explore achievements
              </Button>
            </div>
          </div>
        </div>
      </div>
      <div className="absolute inset-0 -z-10">
        <img
          src="https://d22po4pjz3o32e.cloudfront.net/placeholder-image.svg"
          className="size-full object-cover"
          alt="Relume placeholder image"
        />
        <div className="absolute inset-0 bg-black/50" />
      </div>
    </section>
  );
}
