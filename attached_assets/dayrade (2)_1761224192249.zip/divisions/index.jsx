import React from "react";
import { Navbar6 } from "./components/Navbar6";
import { Header83 } from "./components/Header83";
import { Layout504 } from "./components/Layout504";
import { Layout508 } from "./components/Layout508";
import { Layout514 } from "./components/Layout514";
import { Layout442 } from "./components/Layout442";
import { Footer3 } from "./components/Footer3";

export default function Page() {
  return (
    <div>
      <Navbar6 />
      <Header83 />
      <Layout504 />
      <Layout508 />
      <Layout514 />
      <Layout442 />
      <Footer3 />
    </div>
  );
}
